public class Electronics extends Product {

    /*
    - Additional Attributes: warrantyPeriod (in months)
    - Methods:
        Override the calculateTotalValue method to account for electronics' value increasing by 10% (e.g., handling fees).
        Override toString to include warranty information in the product details.
     */


    //attribute
    private String warrantyPeriod;

    //constructor
    public Electronics(int productID, String name, double price, int quantity, String warrantyPeriod) {
        super(productID, name, price, quantity);
        this.warrantyPeriod = warrantyPeriod;
    }

    /*
    //getter
    public String getWarrantyPeriod(){
        return warrantyPeriod;
    }

    //setter
    public void setWarrantyPeriod(String warrantyPeriod){
        this.warrantyPeriod = warrantyPeriod;
    }
    */

    //override calculateTotalValue
    @Override
    public double calculateTotalValue() {
        double baseTotal = super.calculateTotalValue();
        double handling = 0.1; //10% handling
        return baseTotal + (baseTotal * handling);
    }

    //override toString to include warranty
    @Override
    public String toString() {
        return super.toString() + "Warranty Period: " + warrantyPeriod;
    }
}
