import java.util.ArrayList;
public class Main {
    public static void main(String[] args) {

        ArrayList<Product> inventory = new ArrayList<>();

        /*
        Create instances of Product, Electronics, and Furniture with sample data.
        Demonstrate the use of methods like restock, calculateTotalValue, and toString.
        Implement a method to display the total inventory value of the warehouse (all products combined).
        Demonstrate method overriding through polymorphism with instances of different product types.
         */

        /*
        Requirements:
            Use inheritance to extend the Product class for Electronics and Furniture.
            Implement method overriding for calculating total value in each subclass.
            Use polymorphism to display product details and total values.
            Handle exceptions for incorrect input (e.g., negative quantities).
            Ensure proper encapsulation of class attributes.
            Submit your Java program with appropriate comments to demonstrate the functionality of the Inventory Management System.
         */

        /*
        Sample output:

            Product Inventory:

            Product ID: 101
            Name: Chair
            Price: $50.00
            Quantity: 30
            Material Type: Wood
            Total Value (with handling fee): $1575.00

            Product ID: 102
            Name: Laptop
            Price: $1000.00
            Quantity: 5
            Warranty Period: 24 months
            Total Value (with handling fee): $5500.00

            Restocking Chair by 20 units...
            New Quantity: 50
            New Total Value: $2625.00

            Total Inventory Value: $8125.00
         */

        System.out.println("Product Inventory:" + "\n");

        //instance of product
        Product Electronics = new Product(100, "Phone", 1000.00, 100);
        System.out.println(Electronics.toString());

        System.out.println();

        //instance of electronics
        Electronics Laptop = new Electronics(100, "Laptop", 1000.00, 100, "24 Months");
        System.out.println(Laptop.toString());
        Laptop.restock(10); //restock on laptop

        //adding sample product
        inventory.add(new Electronics(100, "Laptop", 1000.00, 100, "24 months"));

        System.out.println();

        //instance of furniture
        Furniture Table = new Furniture(50, "Table", 500.00, 20, "Wood");
        System.out.println(Table.toString());
        Table.restock(30); //restock of table

        //adding sample product
        inventory.add(new Furniture(50, "Table", 500.00, 20, "Wood"));




        double totalInventoryValue = 0;

        for(Product product : inventory){
            totalInventoryValue += product.calculateTotalValue();
        }

        System.out.println("\n" + "Total Inventory Value: " + totalInventoryValue);

    }
}