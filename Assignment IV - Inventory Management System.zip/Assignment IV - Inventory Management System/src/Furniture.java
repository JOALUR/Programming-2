public class Furniture extends Product{

    /*
    - Additional Attributes: materialType (e.g., wood, metal)
    - Methods:
        Override calculateTotalValue to account for handling fees (5% for furniture).
        Override toString to include material type in the product details.
     */

    //attribute
    private String materialType;

    //constructor
    public Furniture(int productID, String name, double price, int quantity, String materialType){
        super(productID, name, price, quantity);
        this.materialType = materialType;
    }

    /*
    public String getMaterialType(){
        return materialType;
    }

    public void setMaterialType(String materialType) {
        this.materialType = materialType;
    }
    */

    //override total value for furniture
    @Override
    public double calculateTotalValue(){
        double baseTotal = super.calculateTotalValue();
        double handling = 0.05;
        return baseTotal + (baseTotal * handling);
    }

    //override toString
    @Override
    public String toString(){
        return super.toString() + "Material Type: " + materialType;
    }

}
