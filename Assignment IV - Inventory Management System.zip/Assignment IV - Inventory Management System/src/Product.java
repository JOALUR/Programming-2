public class Product {

    /*
    - Attributes: productID, name, price, quantity
    - Methods:
        Accessor and mutator methods for all attributes
        calculateTotalValue: calculates the total value of the stock (price * quantity)
        restock: increases the product quantity by a given amount
        Override toString method to display product details.
     */

    //Attributes for productID, name, price, quantity
    protected int productID;
    protected String name;
    protected double price;
    protected int quantity;

    //constructor
    public Product(int productID, String name, double price, int quantity){
        this.productID = productID;
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    /*
    //accessor (getter) and mutator (setter) method for atributes
    public int getproductID(){
        return productID;
    }

    public void setproductID(int productID){
        this.productID = productID;
    }

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }

    public double getPrice(){
        return price;
    }

    public void setPrice(double price){
        this.price = price;
    }

    public int getQuantity(){
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    */

    //calculate total value
    public double calculateTotalValue(){
       return price * quantity;
    }

    //restock
    public void restock(int amount){
        if(amount > 0){
            this.quantity += amount; //quantity = quantity + amount
            System.out.println("\n" + "Restocking " + name + " by " + amount + "units....");
            System.out.println("New quantity: " + this.quantity);
            System.out.println("New Total Value: " + calculateTotalValue());
        }
        else{
            System.out.println("Invalid restock amount");
        }


    }

    // override toString method displayed product
    @Override
    public String toString(){
        return "Product ID: " + productID + "\n" + "Name: " + name + "\n" + "Price: " + price + "\n" +"Quantity: " + quantity + "\n";
    }

}
