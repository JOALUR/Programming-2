public class Triangle extends Shape implements Resizable {

    private double height;
    private double base;
    private double side_a;
    private double side_c;

    public Triangle(String name, String color, double height, double base, double side_a, double side_c){
        super(name, color);
        this.height = height;
        this.base = base;
        this.side_a = side_a;
        this.side_c = side_c;
    }

    //getter methods
    public double getHeight(){
        return height;
    }

    public double getBase(){
        return base;
    }

    public double getSide_a(){
        return side_a;
    }

    public double getSide_c(){
        return side_c;
    }


    //calling abract method calculateArea from Shape
    @Override
    public double calculateArea(){
        return (.5) * (base * height);
    }

    //calling abract method calculatePerimeter from Shape
    @Override
    public double calculatePerimeter(){
        return side_a + base + side_c;
    }

    //resize method from interface
    @Override
    public void resize(int percent){
        height += height * percent / 100.0;
        base += base * percent / 100.0;
        side_a += side_a * percent / 100.0;
        side_c += side_c * percent / 100.0;
    }

}
