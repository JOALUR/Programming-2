public class Circle extends Shape implements Resizable {

    //properties
    private double radius;
    double pi = 3.14;

    public Circle(String name, String color, double radius){
        super(name, color);
        this.radius = radius;
    }

    //getter methods
    public double getRadius(){
        return radius;
    }

    //calling abract method calculateArea from Shape
    @Override
    public double calculateArea(){
        return pi * (radius * radius);
    }

    //calling abract method calculatePerimeter from Shape
    @Override
    public double calculatePerimeter(){
        return 2 * (pi * radius);
    }

    //resize method from interface
    @Override
    public void resize(int percent){
        radius += radius * percent / 100.0;

    }

}
