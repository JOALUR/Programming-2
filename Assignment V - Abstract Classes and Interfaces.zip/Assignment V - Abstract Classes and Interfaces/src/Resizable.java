public interface Resizable {

    void resize(int percent);

}
