public class Square extends Shape implements Resizable{

    private double side;

    public Square(String name, String color, double side){
        super(name, color);
        this.side = side;
    }

    //getter methods
    public double getSide(){
        return side;
    }

    //calling abract method calculateArea from Shape
    @Override
    public double calculateArea(){
        return (side * side);
    }

    //calling abract method calculatePerimeter from Shape
    @Override
    public double calculatePerimeter(){
        return (4 * side);
    }

    //resize method from interface
    @Override
    public void resize(int percent){
        side += side * percent / 100.0;
    }

}
