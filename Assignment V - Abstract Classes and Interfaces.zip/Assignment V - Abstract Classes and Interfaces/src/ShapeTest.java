public class ShapeTest {
    public static void main(String[] args) {


        //test shape classes
        Circle circle = new Circle("Circle", "Red", 5);
        Rectangle rectangle = new Rectangle("Rectangle", "Blue", 4, 6);
        Triangle triangle = new Triangle("Triangle", "Green", 10, 8, 5, 6);
        Square square = new Square("Square", "Purple", 3);

        System.out.println("Circle: ");
        System.out.println("Name: " + circle.getName());
        System.out.println("Color: " + circle.getColor());
        System.out.println("Radius: " + circle.getRadius());
        System.out.println("Area: " + circle.calculateArea());
        System.out.println("Perimeter: " + circle.calculatePerimeter());
        circle.resize(200);
        System.out.println("Resized Circle - Radius: " + circle.getRadius());

        System.out.println("\nRectangle: ");
        System.out.println("Name: " + rectangle.getName());
        System.out.println("Color: " + rectangle.getColor());
        System.out.println("Length: " + rectangle.getLength());
        System.out.println("Width: " + rectangle.getWidth());
        System.out.println("Area: " + rectangle.calculateArea());
        System.out.println("Perimeter: " + rectangle.calculatePerimeter());
        rectangle.resize(80);
        System.out.println("Resized Rectangle - Length: " + rectangle.getLength() + ", Width: " + rectangle.getWidth());

        System.out.println("\nTriangle: ");
        System.out.println("Name: " + triangle.getName());
        System.out.println("Color: " + triangle.getColor());
        System.out.println("Height: " + triangle.getHeight());
        System.out.println("Base (Side B): " + triangle.getBase());
        System.out.println("Side A: " + triangle.getSide_a());
        System.out.println("Side C: " + triangle.getSide_c());
        System.out.println("Area: " + triangle.calculateArea());
        System.out.println("Perimeter: " + triangle.calculatePerimeter());
        triangle.resize(30);
        System.out.println("Resized Triangle - Height : " + triangle.getHeight() + ", Base: " + triangle.getBase() + ", Side A: " + triangle.getSide_a() + ", Side C: " + triangle.getSide_c());

        System.out.println("\nSquare: ");
        System.out.println("Name: " + square.getName());
        System.out.println("Color: " + square.getColor());
        System.out.println("Side: " + square.getSide());
        System.out.println("Area: " + square.calculateArea());
        System.out.println("Perimeter: " + square.calculatePerimeter());
        square.resize(6000);
        System.out.println("Resized Square - Side: " + square.getSide());





    }
}