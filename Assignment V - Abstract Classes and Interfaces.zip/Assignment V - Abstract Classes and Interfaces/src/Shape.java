public abstract class Shape {


    //Properties
    protected String name;
    protected String color;

    public Shape(String name, String color) {
        this.name = name;
        this.color = color;
    }

    //abstract method calculateArea
    public abstract double calculateArea();{

    }

    //abstract method calculatePerimeter
    public abstract double calculatePerimeter();{

    }

    public String getName(){
        return name;
    }

    public String getColor(){
        return color;
    }

}
