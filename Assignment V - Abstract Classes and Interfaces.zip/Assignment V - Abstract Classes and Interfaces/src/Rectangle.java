public class Rectangle extends Shape implements Resizable {


    private double length;
    private double width;

    public Rectangle(String name, String color, double length, double width){
        super(name, color);
        this.length = length;
        this.width = width;
    }

    //getter methods
    public double getLength(){
        return length;
    }

    public double getWidth(){
        return width;
    }

    //calling abract method calculateArea from Shape
    @Override
    public double calculateArea(){
        return length * width;
    }

    //calling abract method calculatePerimeter from Shape
    @Override
    public double calculatePerimeter(){
        return 2 * (length + width);
    }

    //resize method from interface
    @Override
    public void resize(int percent){
        length += length * percent / 100.0;
        width += width * percent / 100.0;
    }

}
