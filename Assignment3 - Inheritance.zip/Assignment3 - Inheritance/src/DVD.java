public class DVD extends LibraryItem {
    private String director;
    private int duration; // duration in minutes

    public DVD(String title, String creator, int itemId, String director, int duration) {
        super(title, creator, itemId);
        this.director = director;
        this.duration = duration;
    }

    @Override
    public String toString() {
        return super.toString() + ", Director: " + director + ", Duration: " + duration + " mins";
    }
}
