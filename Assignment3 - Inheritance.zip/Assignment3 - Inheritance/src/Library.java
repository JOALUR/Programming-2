public class Library{
    private LibraryItem[] items;
    private int itemCount;
    private LibraryMember[] members;
    private int memberCount;

    public Library() {
        this.items = new LibraryItem[10]; // Initial capacity for items.
        this.itemCount = 0;
        this.members = new LibraryMember[10]; // Initial capacity for members.
        this.memberCount = 0;
    }

    public void addItem(LibraryItem item) {
        if (itemCount >= items.length) {
            resizeItemsArray();
        }
        items[itemCount++] = item;
    }

    public void addMember(LibraryMember member) {
        if (memberCount >= members.length) {
            resizeMembersArray();
        }
        members[memberCount++] = member;
    }

    public LibraryItem findItemById(int itemId) {
        for (int i = 0; i < itemCount; i++) {
            if (items[i].getItemId() == itemId) {
                return items[i];
            }
        }
        return null;
    }

    public LibraryMember findMemberById(int memberId) {
        for (int i = 0; i < memberCount; i++) {
            if (members[i].getMemberId() == memberId) {
                return members[i];
            }
        }
        return null;
    }

    private void resizeItemsArray() {
        LibraryItem[] newItems = new LibraryItem[items.length * 2];
        System.arraycopy(items, 0, newItems, 0, items.length);
        items = newItems;
    }

    private void resizeMembersArray() {
        LibraryMember[] newMembers = new LibraryMember[members.length * 2];
        System.arraycopy(members, 0, newMembers, 0, members.length);
        members = newMembers;
    }

    @Override
    public String toString() {
        return "Library: Items - " + itemCount + ", Members - " + memberCount;
    }
}
