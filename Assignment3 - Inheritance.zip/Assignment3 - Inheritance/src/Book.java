public class Book extends LibraryItem {
    private String genre;
    private int numberOfPages;

    public Book(String title, String creator, int itemId, String genre, int numberOfPages) {
        super(title, creator, itemId);
        this.genre = genre;
        this.numberOfPages = numberOfPages;
    }

    @Override
    public String toString() {
        return super.toString() + ", Genre: " + genre + ", Pages: " + numberOfPages;
    }
}
