public class LibraryMember{
    private String name;
    private String address;
    private String contact;
    private int memberId;
    private LibraryItem[] borrowedItems;
    private int borrowedItemCount;
    private double fines;

    public LibraryMember(String name, String address, String contact, int memberId) {
        this.name = name;
        this.address = address;
        this.contact = contact;
        this.memberId = memberId;
        this.borrowedItems = new LibraryItem[10]; // Initial capacity for borrowed items.
        this.borrowedItemCount = 0;
        this.fines = 0.0;
    }

    public void borrowItem(LibraryItem item) {
        if (item.isAvailable() && borrowedItemCount < borrowedItems.length) {
            item.checkoutItem();
            borrowedItems[borrowedItemCount++] = item;
        } else {
            System.out.println("Cannot borrow more items or item is not available.");
        }
    }

    public void returnItem(LibraryItem item) {
        for (int i = 0; i < borrowedItemCount; i++) {
            if (borrowedItems[i] == item) {
                item.returnItem();
                // Shift remaining items to the left
                for (int j = i; j < borrowedItemCount - 1; j++) {
                    borrowedItems[j] = borrowedItems[j + 1];
                }
                borrowedItems[--borrowedItemCount] = null;
                return;
            }
        }
        System.out.println("Item not found in borrowed list.");
    }

    public int getMemberId() {
        return memberId;
    }

    @Override
    public String toString() {
        return "Member ID: " + memberId + ", Name: " + name + ", Borrowed Items: " + borrowedItemCount;
    }
}
