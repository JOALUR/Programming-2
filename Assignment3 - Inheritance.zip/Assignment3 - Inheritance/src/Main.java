import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Library library = new Library();

        while (true) {
            System.out.println("\n1. Add item");
            System.out.println("2. Add member");
            System.out.println("3. Borrow item");
            System.out.println("4. Return item");
            System.out.println("5. Display library");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addItemToLibrary(scanner, library);
                    break;
                case 2:
                    addMemberToLibrary(scanner, library);
                    break;
                case 3:
                    borrowItem(scanner, library);
                    break;
                case 4:
                    returnItem(scanner, library);
                    break;
                case 5:
                    System.out.println(library);
                    break;
                case 6:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addItemToLibrary(Scanner scanner, Library library) {
        System.out.print("Enter title: ");
        scanner.nextLine(); // consume newline
        String title = scanner.nextLine();
        System.out.print("Enter creator: ");
        String creator = scanner.nextLine();
        System.out.print("Enter item ID: ");
        int itemId = scanner.nextInt();
        System.out.print("Is it a book or a DVD (B/D): ");
        char type = scanner.next().charAt(0);

        if (type == 'B' || type == 'b') {
            System.out.print("Enter genre: ");
            scanner.nextLine(); // consume newline
            String genre = scanner.nextLine();
            System.out.print("Enter number of pages: ");
            int pages = scanner.nextInt();
            Book book = new Book(title, creator, itemId, genre, pages);
            library.addItem(book);
        } else if (type == 'D' || type == 'd') {
            System.out.print("Enter director: ");
            scanner.nextLine(); // consume newline
            String director = scanner.nextLine();
            System.out.print("Enter duration: ");
            int duration = scanner.nextInt();
            DVD dvd = new DVD(title, creator, itemId, director, duration);
            library.addItem(dvd);
        } else {
            System.out.println("Invalid type. Please enter B for Book or D for DVD.");
        }
    }

    private static void addMemberToLibrary(Scanner scanner, Library library) {
        System.out.print("Enter name: ");
        scanner.nextLine(); // consume newline
        String name = scanner.nextLine();
        System.out.print("Enter address: ");
        String address = scanner.nextLine();
        System.out.print("Enter contact: ");
        String contact = scanner.nextLine();
        System.out.print("Enter member ID: ");
        int memberId = scanner.nextInt();
        LibraryMember member = new LibraryMember(name, address, contact, memberId);
        library.addMember(member);
    }

    private static void borrowItem(Scanner scanner, Library library) {
        System.out.print("Enter member ID: ");
        int memberId = scanner.nextInt();
        LibraryMember member = library.findMemberById(memberId);
        if (member == null) {
            System.out.println("Member not found.");
            return;
        }
        System.out.print("Enter item ID to borrow: ");
        int itemId = scanner.nextInt();
        LibraryItem item = library.findItemById(itemId);
        if (item == null) {
            System.out.println("Item not found.");
            return;
        }
        member.borrowItem(item);
    }

    private static void returnItem(Scanner scanner, Library library) {
        System.out.print("Enter member ID: ");
        int memberId = scanner.nextInt();
        LibraryMember member = library.findMemberById(memberId);
        if (member == null) {
            System.out.println("Member not found.");
            return;
        }
        System.out.print("Enter item ID to return: ");
        int itemId = scanner.nextInt();
        LibraryItem item = library.findItemById(itemId);
        if (item == null) {
            System.out.println("Item not found.");
            return;
        }
        member.returnItem(item);

    }
}