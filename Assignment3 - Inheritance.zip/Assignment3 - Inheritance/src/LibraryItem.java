public class LibraryItem {
    protected String title;
    protected String creator;
    protected int itemId;
    protected boolean available;

    public LibraryItem(String title, String creator, int itemId) {
        this.title = title;
        this.creator = creator;
        this.itemId = itemId;
        this.available = true; // Items are available by default when added.
    }

    public void checkoutItem() {
        if (this.available) {
            this.available = false;
            System.out.println("Item checked out successfully.");
        } else {
            System.out.println("Item is not available for borrowing.");
        }
    }

    public void returnItem() {
        this.available = true;
        System.out.println("Item returned successfully.");
    }

    public boolean isAvailable() {
        return available;
    }

    public int getItemId() {
        return itemId;
    }

    @Override
    public String toString() {
        return "ID: " + itemId + ", Title: " + title + ", Creator: " + creator + ", Available: " + available;
    }
}
