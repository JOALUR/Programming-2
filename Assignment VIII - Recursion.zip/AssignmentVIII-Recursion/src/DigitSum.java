public class DigitSum {

    /*
        Define a Java class named DigitSum.
        Inside the class, implement a method named sumOfDigits that takes an integer n
        (the number whose digits are to be summed) and returns an integer (the sum of its digits).
        Use recursion to solve the problem.
        The base case is when n is less than 10, return n itself.
        For n greater than or equal to 10, the sum of digits can be calculated as the sum of the
        last digit (n % 10) and the sum of digits of the remaining part (n / 10), which can be calculated recursively.

     */

    //method sumOfDigits
    public int sumOfDigits(int n){
        //base case when n is less than 10, returns n
        if(n < 10){
            return n;
        }
        //returns sum of last digit and remaining digits
        return (n % 10) + sumOfDigits(n/10);
    }

}
