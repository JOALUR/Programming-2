public class Main {
    public static void main(String[] args) {


        //call sumOfDigits method
        DigitSum digitSum = new DigitSum();
        //sample input for n
        int n = 169324;
        //int for result of digitSum
        int result = digitSum.sumOfDigits(n);
        //output for sum of digits
        System.out.println("\nSum of digits for " + n + ": " + result);


        //call totalHandshakes method
        Handshakes handshakes = new Handshakes();
        //sample input for j
        int j = 13;
        //int for result of total Handshakes
        int total = handshakes.totalHandshakes(j);
        //output for total num of handshakes
        System.out.println("\nTotal number of handshakes for " + j + " people: " + total);






    }
}