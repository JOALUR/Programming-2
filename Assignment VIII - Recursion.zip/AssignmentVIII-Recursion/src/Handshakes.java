public class Handshakes{

    /*
    Define a Java class named Handshakes.
    Inside the class, implement a method named totalHandshakes
    that takes an integer n (number of people) and returns an
    integer (total number of handshakes).
    Use recursion to solve the problem.
    The base cases are:
    If n is less than or equal to 1, return 0
    (no handshakes occur with less than two people).
    If n is equal to 2, return 1 (one handshake occurs with two people).
    For n greater than 2, the total number of handshakes can be
    calculated as n - 1 + totalHandshakes(n - 1).
     */

    //method totalHandshakes to take int n and return an int
    public int totalHandshakes(int j){
        //if n is less than or equal to 1, return 0
        if(j <= 1){
            return 0;
            //no handshakes occur with less than two people
        }
        //if n is equal to 2, return 1
        else if(j == 2){
            return 1;
        }
        else{
            return (j - 1) + totalHandshakes(j -1);
        }

    }

}