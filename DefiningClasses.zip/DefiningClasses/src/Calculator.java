public class Calculator {

    //private double field value
    private double value;

    //constructor to initialize value field to 0.0
    public Calculator(){this.value = 0.0;}

    //instance methods in calculator class
    public void add(double val){this.value += val;}
    public void subtract(double val){this.value -= val;};
    public void multiply(double val){this.value *= val;};
    public void divide(double val){
        if (val == 0){
            System.out.println("Error: Can't divide by zero.");
        }
        else{
            this.value /= val;
        }
    };
    public void clear(){this.value = 0.0;};

    
    //method to return current value of value field
    public double getValue() 
    {
        return this.value;
    }

}
