import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        //instance of Calculator class
        Calculator calculator = new Calculator();

        //Insert scanner obj
        Scanner scannerObj = new Scanner(System.in);

        //two double input values from user
        System.out.println("Please enter a number:");
        Double num1 = scannerObj.nextDouble();
        System.out.println("Please enter a second number:");
        Double num2 = scannerObj.nextDouble();

        //initial value of calculator
        System.out.println("Initial value: " + calculator.getValue());

        /*add num 1 to calculator's value and print new value
          subtract num 2 from current value and print new value
          divide currentvalue by 2 and print the new value. if
          division by zero is attempted, print an error message instead
          clear the calculator's value and print new value (0.0)
        */
        calculator.add(num1);
        System.out.println(num1 + calculator.getValue());

        calculator.multiply(3);
        System.out.println(calculator.getValue());

        calculator.subtract(num2);
        System.out.println(num2 + calculator.getValue());

        calculator.divide(2);
        System.out.println(calculator.getValue());

        calculator.clear();
        System.out.println(calculator.getValue());

        scannerObj.close();

    }

}