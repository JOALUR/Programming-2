public class Engine {

    /*Constructor to initialize engineNumber and power.
      A toString() method to display the engine's details.
    */

    private String EngineNo;
    public int EnginePower;

    //Constructor for EngineNo and Power
    public Engine(String EngineNo, int EnginePower){

        this.EngineNo = EngineNo;
        this.EnginePower = EnginePower;

    }
    //toString() to display engine details
    public String toString(){
        return "Engine Number is " + this.EngineNo + " and the Engine Power is " + this.EnginePower + ".";




    }
}
