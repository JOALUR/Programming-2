public class Car {

    /* Constructor to initialize the model and brand.
    Getter and Setter for the Engine.
    A toString() method to display the car's information
    along with the engine details. */


    public String carBrand;
    public String carModel;
    private Engine engine;

    //Constructor for model and brand
    public Car(String carBrand, String carModel) {

        this.carBrand = carBrand;
        this.carModel = carModel;

    }
    //Getter and Setter for Engine
    public Engine getEngine() { return this.engine; }
    public void setEngine(Engine engine) {this.engine = engine;}

    //toString() to display car info with engine details
    public String toString(){
        return "Car brand is " + this.carBrand + ", Car model is " + this.carModel + ", and the engine is a " + engine;


    }
}
