public class Main {
    public static void main(String[] args) {

        //Instances of Car and Engine
        Car Porsche = new Car("Porsche", "918 Spyder");

        Engine PorscheEngine = new Engine( "123456789", 4593);

        // "4.6 L V8 engine" --- engine
        //Set engine for car
        Porsche.setEngine(PorscheEngine);

        //printed details of both car and engine using toString()
        System.out.println(Porsche);
        System.out.println(PorscheEngine);

    }


}