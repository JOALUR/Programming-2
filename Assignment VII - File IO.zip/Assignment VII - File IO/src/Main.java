import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        //scanner for user input
        Scanner scan = new Scanner(System.in);

        //prompt user to enter file name
        System.out.println("Enter the name of the file to edit (text.txt): ");
        String inputFileName = scan.nextLine();

        //generates unique temporary file
        File file = generateTempFile();

        //check if file exists before moving on
        File testFile = new File(inputFileName);
        if (!testFile.exists()){
            System.out.println("File not found. Please check file path. ");
            return;
        }
        else{
            System.out.println("File found. Proceeding with operartion... ");
        }

        //read input file and write sentences to temp file, each on a new line
        try(
                BufferedReader reader = new BufferedReader(new FileReader(inputFileName));
                BufferedWriter writer = new BufferedWriter(new FileWriter(file));
                ){

            //read the content and write each sentence on a new line
            String line;
            while((line = reader.readLine()) != null){
                //splitting line into sentences
                String[] sentences = line.split("\\. ");
                for(String sentence : sentences){
                    //write sentence without period
                    writer.write(sentence.trim());
                    //moves to new line for each sentence
                    writer.newLine();
                }
            }

        }
        catch(IOException e){
            System.out.println("An error occurred while processing the file: " + e.getMessage());
        }

        //copy contents of temp file back to original file
        try(
                BufferedReader tempReader = new BufferedReader(new FileReader(file));
                BufferedWriter originalWriter = new BufferedWriter(new FileWriter(inputFileName));
                ){
            String line;
            while((line = tempReader.readLine()) != null){
                originalWriter.write(line);
                originalWriter.newLine();
            }
        }
        catch(IOException e){
            System.out.println("An error occurred while copying content back to original file: " + e.getMessage());
        }

        //delete temp file after copying
        if(file.delete()){
            System.out.println("Temporary file deleted successfully.");
        }
        else{
            System.out.println("Failed to delete temporary file.");
        }

        scan.close();

    }

    //method to generate unique temp file
    private static File generateTempFile() {
        int counter = 1;
        File tempFile;
        do{
            tempFile = new File("Temp" + counter + ".txt");
            counter++;
        }
        while(tempFile.exists());
        return tempFile;
    }
}