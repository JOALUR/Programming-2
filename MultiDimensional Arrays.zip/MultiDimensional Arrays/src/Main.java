import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        /*
           -display seats
           -begin while loop
           -ask for user input on seats
           -begin if/else statements for valid responses
           -replace character with 'X' if seat selected by user
           -check for available seats
           -option to quit
           -automatically quit if all seats are used
         */

        //input scannerobj
        Scanner scannerObj = new Scanner(System.in);

        //initialize 2d array for seats
        byte[][] trainSeats = new byte[5][4];
        //5 rows, 4 seats

        //seat letters
        char[] seats = {'A','B','C','D'};

        //variables for free and occupied seats
        byte freeTrainSeats = 20, occupiedTrainSeats = 0;

        while(true){
            //display intial seating
            System.out.println("Current Seating:");
            System.out.println("\tA\tB\tC\tD");

            for(int row = 0; row<trainSeats.length; row++){
                System.out.print((row + 1) + "\t");
                for(int col = 0; col < trainSeats[row].length; col++){

                    //Display 'X' for occupied seats
                    if(trainSeats[row][col] == 1){
                        System.out.print("X\t");
                    }
                    else{
                        System.out.print(seats[col] + "\t");
                    }
                }
                System.out.println();
            }
            //free and occupied seats
            System.out.println("Free seats: " + freeTrainSeats + " | Occupied seats: " + occupiedTrainSeats);

            //user input
            System.out.print("Enter seat row (1-5) and column (A-D) or 'Q' to quit: \n");
            System.out.println("Enter number then letter (ex: 1D, don't do 'D1')");
            String input = scannerObj.nextLine();

            if(input.equalsIgnoreCase("Q")){
                System.out.println("Program exited.");
                break;
            }

            //validate input length (2 characters like "3C")
            if(input.length()==2){
                int row = Character.getNumericValue(input.charAt(0)) - 1;
                char colChar = input.charAt(1);

                //determine column index based on sea label
                int col = -1;
                switch(colChar){
                    case 'A': col = 0; break;
                    case 'B': col = 1; break;
                    case 'C': col = 2; break;
                    case 'D': col = 3; break;
                    default:
                        System.out.println("Invalid seat label. Try again.");
                        continue;
                }

                if (row >= 0 && row < trainSeats.length && col >= 0 && col < trainSeats[row].length){

                    //check is seat occupied
                    if(trainSeats[row][col]==1){
                        System.out.println("Seat " + input + " is already occupied. Please choose another seat.");
                    }
                    else{
                        //Mark seat as occupied
                        trainSeats[row][col] = 1;
                        freeTrainSeats--;
                        occupiedTrainSeats++;
                        System.out.println("Seat " + input + " booked successfully.");
                    }

                }else{
                    System.out.println("Invalid seat choice. Try again.");
                }

            }else{
                System.out.println("Invalid input format. Enter in format shown (ex: 1C).");
            }
            //check if seats filled
            if(freeTrainSeats == 0){
                System.out.println("All seats are booked!!!");
                break;
            }


        }





        scannerObj.close();
    }
}