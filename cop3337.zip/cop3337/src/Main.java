//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        int x;
        double age;

        Person abdul=new Person("Abdul Rehman", "1-1-90","brown");

        Passport abdulPassport= new Passport("1234","1-1-30",abdul);

        System.out.println(abdulPassport);


    }
}