public class Passport {

    private String passportNo;
    private String expiry;
    private Person person;


    public Passport(String passportNo, String expiry, Person person) {
        this.passportNo=passportNo;
        this.expiry=expiry;
        this.person=person;
    }

    public String toString(){
        return "Passport No : "+ this.passportNo + " belongs to : "+ this.person.name;
    }
}
