public class Person {
    public String name;
    private String DOB;
    public String color;


    public Person(String name, String PersonDOB, String PersonColor) {
        this.name=name;
        this.color=PersonColor;
        this.DOB=PersonDOB;
    }
    public String getDOB()
    {
        return this.DOB;
    }
    public void setDOB(String dob)
    {
        this.DOB=dob;
    }

    public String toString()
    {
        return "Person name is " + this.name + "my color is " + this.color + " and my dob is " + this.DOB;
    }
}
