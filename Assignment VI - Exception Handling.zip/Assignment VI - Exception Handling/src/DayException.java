public class DayException extends Exception {
    //custom exception for invalid days
    public DayException(String message) {
      super(message);
    }
}
