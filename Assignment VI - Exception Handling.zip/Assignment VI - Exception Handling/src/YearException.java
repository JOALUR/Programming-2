public class YearException extends Exception {
    //custom exception for invalid years
    public YearException(String message) {
        super(message);
    }
}
