public class MonthException extends Exception {
    //custom exception for invalid months
    public MonthException(String message){
        super(message);
    }
}
