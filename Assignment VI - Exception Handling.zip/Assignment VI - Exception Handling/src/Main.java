import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        
        //scanner for user input
        Scanner scan = new Scanner(System.in);

        //string for userinput
        String userInput;

        //while loop to countinuously ask for date until valid date
        while(true){
            //print statement prompting user to enter date in mm/dd/yyyy format
            System.out.println("Enter a date in MM/DD/YYYY format: ");
            //user input for print statement above
            userInput = scan.nextLine();

            try{
                //splitting user input into month, day, and year
                String[] parts = userInput.split("/");

                //check if input is formatted with 3 parts
                if(parts.length != 3){
                    throw new ArrayIndexOutOfBoundsException("Invalid date format. Please use MM/DD/YYYY.");
                }

                //parts from mm/dd/yyyy
                String month = parts[0];
                String day = parts[1];
                String year = parts[2];

                //convert month, day, and year to ints
                int monthInt = Integer.parseInt(month);
                int dayInt = Integer.parseInt(day);
                int yearInt = Integer.parseInt(year);

                //check if year is valid, 1000-3000
                if(yearInt < 1000 || yearInt > 3000) {
                    //exception if year in invalid
                    throw new YearException("Invalid year. Please enter a year between 1000 and 3000.");
                }

                //if loop making sure month is valid, 1-12
                if(monthInt < 1 || monthInt > 12){
                    //exception if month is invalid
                    throw new MonthException("Invalid Month. Please enter a month between 1 and 12.");
                }

                //check if day is valid for month and year
                if(!isValidDay(monthInt, dayInt, yearInt)){
                    //exception if day is invalid
                    throw new DayException("Invalid day. Please a valid day for given months.");
                }

                //printing out date and converting month int to string name
                System.out.println("Formatted date: " + getMonthName(monthInt) + " " + dayInt + ", " + yearInt);
                //break loop if valid
                break;

            }
            catch(ArrayIndexOutOfBoundsException | NumberFormatException e){
                System.out.println("Invalid date format. Please use MM/DD/YYYY format.");
            }
            catch (MonthException | DayException | YearException e){
                //prints custom error message
                System.out.println(e.getMessage());
            }
        }
    }

    //Method to check if day is valid for given month
    public static boolean isValidDay(int month, int day, int year){
        switch(month){
            //months with 31 days
            case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                return day >= 1 && day <= 31;
            //month with 30 days
            case 4: case 6: case 9: case 11:
                return day >= 1 && day <= 30;
            //february with 28 or 29 days, check for leap yr
            case 2:
                if(isLeapYear(year)){
                    return day >= 1 && day <= 29;
                }
                else{
                    return day >= 1 && day <= 28;
                }
            default:
                return false;
        }
    }

    //method checking if a year is a leap year
    public static boolean isLeapYear(int year){
        if (year % 4 == 0){
            if (year % 100 == 0){
                return year % 400 == 0;
                //leap year if divisible by 400
            }
            else{
                return true;
            }
        }
        return false;
    }

    //method converting int month to month name using switch
    public static String getMonthName(int month){
        switch(month){
            //each case represents the month numerically and converts it to its name
            //Ex: 1 is Janurary, 2 is February, and so on
            case 1: return "January";
            case 2: return "February";
            case 3: return "March";
            case 4: return "April";
            case 5: return "May";
            case 6: return "June";
            case 7: return "July";
            case 8: return "August";
            case 9: return "September";
            case 10: return "October";
            case 11: return "November";
            case 12: return "December";
            default: return "Invalid Month";
        }
    }

}